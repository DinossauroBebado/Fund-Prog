//Escreva um programa que contenha duas vari�veis inteiras. Compare seus endere�os e exiba o maior
//endere�o.
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
int main(){
int X,Y;


if(&X>&Y){
    printf("Maior endereco : %d",&X);
}else{
 printf("Maior endereco : %d",&Y);}



}
